<?php
header('location:shop.php');
?>